# ScamShield AI — Prototype Source Code

## Files
- `index.html` — responsive web demo interface
- `style.css` — layout, styling, responsive design
- `script.js` — local rule-based URL/message warning checks

## Run the demo
1. Extract the ZIP file.
2. Open `index.html` in a modern web browser.
3. Choose **Link check** or **Message check**, enter a sample, then press **Analyse now**.
4. Use the sample buttons to try example inputs.

No server or API key is required. The checks run locally in the browser; no data is uploaded by this demo.

## Important limitations
This is an educational prototype and not a production security scanner. It uses basic heuristics, not a real AI model or live threat-intelligence service. It can miss scams and can flag legitimate content. A low-risk result does not guarantee safety.

## Suggested next steps
- Test with a documented set of safe sample URLs and scam-style messages.
- Add a reputable threat-intelligence API only after reviewing its privacy terms and usage limits.
- Add accessible language options and clear privacy notices.
- Never collect or store passwords, PINs, CVVs, or OTPs.
